@echo off
setlocal
cd /d "%~dp0"
echo Building the standalone Birds Client portable EXE...
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is needed only to BUILD the EXE on this PC.
  echo You do not need Node.js to RUN the finished Birds Client EXE.
  echo Alternatively, use the GitHub Actions workflow to build it in the cloud.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto failed
call npm run dist
if errorlevel 1 goto failed
echo.
echo Build complete. The standalone EXE is in the dist folder.
explorer "%~dp0dist"
pause
exit /b 0
:failed
echo.
echo Build failed. Check the error above.
pause
exit /b 1
