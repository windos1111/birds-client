# Birds Client

A dark-themed Minecraft mod manager UI for Windows, with Modrinth and CurseForge catalogue search and local mod-folder management.

## Run the finished app

The Windows portable build is a standalone `Birds-Client-1.0.0-Portable.exe`. Users do not need Node.js or a separate Electron installation to run it. Download the EXE, then double-click it.

## Build locally

1. Install Node.js 22 or newer.
2. Open a terminal in this folder.
3. Run `npm install` and then `npm run dist`.
4. Find the portable EXE in `dist/`.

## Build in GitHub Actions

Push this project to a GitHub repository on the `main` branch, or manually run **Actions → Build Birds Client portable EXE → Run workflow**. Download the `Birds-Client-Portable-EXE` artifact from the completed workflow run.

## Notes

- Modrinth search uses its public API.
- CurseForge features require the user's own API key.
- This release is a mod manager shell, not a full Minecraft launcher: Microsoft sign-in, game installation, and game launching are not included.
