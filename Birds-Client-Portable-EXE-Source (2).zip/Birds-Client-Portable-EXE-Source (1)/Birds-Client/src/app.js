
const $ = s => document.querySelector(s);

let source = 'modrinth';
let modsFolder = localStorage.getItem('birds-folder') || '';

function toast(msg) {
  const t = $('#toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}

function page(name) {
  document.querySelectorAll('.page').forEach(p =>
    p.classList.toggle('active', p.id === name)
  );

  document.querySelectorAll('.nav').forEach(n =>
    n.classList.toggle('active', n.dataset.page === name)
  );

  const labels = {
    home: 'HOME',
    mods: 'MOD LIBRARY',
    installed: 'INSTALLED MODS',
    profiles: 'PROFILES',
    servers: 'SERVERS',
    settings: 'SETTINGS'
  };

  if ($('#crumb')) {
    $('#crumb').textContent = labels[name] || name.toUpperCase();
  }

  if (name === 'installed') refreshInstalled();
}

document.querySelectorAll('.nav').forEach(n => {
  n.addEventListener('click', () => page(n.dataset.page));
});

document.querySelectorAll('[data-goto]').forEach(n => {
  n.addEventListener('click', () => page(n.dataset.goto));
});

async function copyText(value) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
    } else {
      const area = document.createElement('textarea');
      area.value = value;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();

      const copied = document.execCommand('copy');
      area.remove();

      if (!copied) throw new Error('Copy failed');
    }

    toast('Server IP copied!');
  } catch {
    toast('Could not copy. Try selecting the IP manually.');
  }
}

document.querySelectorAll('.copy-server').forEach(button => {
  button.addEventListener('click', event => {
    event.stopPropagation();
    const ip = button.dataset.ip;
    if (ip) copyText(ip);
  });
});

function setFolder(path) {
  if (!path) return;

  modsFolder = path;
  localStorage.setItem('birds-folder', path);

  if ($('#folderText')) $('#folderText').textContent = path;
  if ($('#settingsFolder')) $('#settingsFolder').textContent = path;

  refreshInstalled();
  toast('Minecraft mods folder connected.');
}

async function chooseFolder() {
  try {
    setFolder(await window.birds.pickFolder());
  } catch (e) {
    toast(e.message);
  }
}

if ($('#changeFolder')) $('#changeFolder').onclick = chooseFolder;
if ($('#settingsFolderBtn')) $('#settingsFolderBtn').onclick = chooseFolder;
if ($('#refreshMods')) $('#refreshMods').onclick = refreshInstalled;

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[c]));
}

async function refreshInstalled() {
  if (!modsFolder) {
    $('#installedList').innerHTML = `
      <div class="empty-state">
        <div class="empty-glyph">◈</div>
        <h3>No folder connected</h3>
        <p>Choose your Minecraft instance mods folder above.</p>
      </div>`;
    return;
  }

  try {
    const list = await window.birds.listMods(modsFolder);

    $('#installedList').innerHTML = list.length
      ? list.map(m => `
        <div class="installed-row">
          <span style="color:#8adfff">◈</span>
          <b>${esc(m.name)}</b>
          <small>JAR MOD</small>
          <button class="remove" data-file="${encodeURIComponent(m.path)}">Remove</button>
        </div>
      `).join('')
      : `
        <div class="empty-state">
          <div class="empty-glyph">✧</div>
          <h3>No mods found</h3>
          <p>Your selected folder does not contain any .jar mods yet.</p>
        </div>`;

    document.querySelectorAll('.remove').forEach(button => {
      button.onclick = async () => {
        try {
          await window.birds.removeMod(
            decodeURIComponent(button.dataset.file)
          );
          toast('Mod removed.');
          refreshInstalled();
        } catch (e) {
          toast(e.message);
        }
      };
    });
  } catch (e) {
    toast(e.message);
  }
}

document.querySelectorAll('.source').forEach(button => {
  button.onclick = () => {
    source = button.dataset.source;

    document.querySelectorAll('.source').forEach(item =>
      item.classList.toggle('active', item === button)
    );

    $('#resultLabel').textContent =
      'POPULAR ON ' + source.toUpperCase();

    $('#results').innerHTML = `
      <div class="empty-state">
        <div class="empty-glyph">✧</div>
        <h3>Search the ${source === 'modrinth' ? 'Modrinth' : 'CurseForge'} catalogue.</h3>
        <p>Enter a name or choose a suggestion to begin.</p>
      </div>`;
  };
});

document.querySelectorAll('[data-search]').forEach(button => {
  button.onclick = () => {
    $('#query').value = button.dataset.search;
    search();
  };
});

$('#searchBtn').onclick = search;

$('#query').addEventListener('keydown', event => {
  if (event.key === 'Enter') search();
});

async function search() {
  const q = $('#query').value.trim();

  if (!q) {
    toast('Type a mod name to search.');
    return;
  }

  $('#results').innerHTML = `
    <div class="empty-state">
      <div class="empty-glyph">◌</div>
      <h3>Searching the catalogue…</h3>
      <p>Fetching live project information.</p>
    </div>`;

  $('#resultCount').textContent = 'Loading';

  try {
    let items;

    if (source === 'modrinth') {
      const d = await window.birds.searchModrinth(
        q,
        $('#loader').value,
        $('#version').value
      );

      items = d.hits.map(m => ({
        id: m.project_id,
        title: m.title,
        description: m.description,
        icon: m.icon_url,
        downloads: m.downloads,
        author: m.author,
        source: 'modrinth',
        url: m.slug
      }));
    } else {
      const d = await window.birds.searchCurseForge(
        q,
        $('#version').value,
        $('#loader').value
      );

      items = d.data.map(m => ({
        id: m.id,
        title: m.name,
        description: m.summary,
        icon: m.logo?.url,
        downloads: m.downloadCount,
        author: m.authors?.[0]?.name,
        source: 'curseforge',
        url: m.links?.websiteUrl
      }));
    }

    $('#resultCount').textContent = items.length + ' PROJECTS';

    $('#results').innerHTML = items.length
      ? items.map(m => `
        <article class="mod-card">
          <img class="mod-icon" src="${esc(m.icon || '')}"
            onerror="this.style.visibility='hidden'">

          <div class="mod-info">
            <h3>${esc(m.title)}</h3>
            <p>${esc(m.description)}</p>
            <div class="mod-meta">
              <span>↓ ${Number(m.downloads || 0).toLocaleString()}</span>
              <span>${esc(m.author || 'Community')}</span>
              <span>${m.source === 'modrinth' ? 'MODRINTH' : 'CURSEFORGE'}</span>
            </div>
          </div>

          <div class="mod-actions">
            <button class="install"
              data-id="${esc(m.id)}"
              data-source="${m.source}"
              data-title="${esc(m.title)}">
              Install
            </button>
          </div>
        </article>
      `).join('')
      : `
        <div class="empty-state">
          <h3>No matching projects</h3>
          <p>Try another search term or source.</p>
        </div>`;

    document.querySelectorAll('.install').forEach(button => {
      button.onclick = async () => {
        try {
          if (!modsFolder) {
            toast('Choose your Minecraft mods folder in Settings first.');
            page('settings');
            return;
          }

          const versions = button.dataset.source === 'modrinth'
            ? await window.birds.getModrinthFiles(
                button.dataset.id,
                $('#loader').value,
                $('#version').value
              )
            : await window.birds.getCurseForgeFiles(
                button.dataset.id,
                $('#version').value,
                $('#loader').value
              );

          if (!versions.length) {
            toast('No compatible files found for those filters.');
            return;
          }

          const chosen = versions[0].files[0];

          if (!chosen.url) {
            toast('This project has no direct download available.');
            return;
          }

          const confirmed = confirm(
            'Install ' + button.dataset.title +
            ' (' + chosen.filename +
            ') into your selected mods folder?'
          );

          if (!confirmed) return;

          await window.birds.installMod({
            url: chosen.url,
            filename: chosen.filename,
            folder: modsFolder
          });

          toast('Mod installed successfully.');
          refreshInstalled();
        } catch (e) {
          toast(e.message);
        }
      };
    });
  } catch (e) {
    $('#results').innerHTML = `
      <div class="empty-state">
        <div class="empty-glyph">!</div>
        <h3>Could not load this catalogue.</h3>
        <p>${esc(e.message)}</p>
      </div>`;

    $('#resultCount').textContent = 'SOURCE ERROR';
  }
}

$('#saveKey').onclick = async () => {
  try {
    await window.birds.saveCurseForgeKey($('#cfKey').value);
    $('#cfKey').value = '';
    toast('CurseForge API key saved securely on this device.');
  } catch (e) {
    toast(e.message);
  }
};

if (modsFolder) {
  if ($('#folderText')) $('#folderText').textContent = modsFolder;
  if ($('#settingsFolder')) $('#settingsFolder').textContent = modsFolder;
}
